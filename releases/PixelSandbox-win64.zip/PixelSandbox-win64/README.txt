Pixel Sandbox (early build) - Windows 64-bit

Run: double-click pixel_sandbox.exe (keep SDL2.dll in the same folder).

You start on a generated world that wraps around: keep walking right (or
left) and you come back to where you started. Every seed gives a different
world - press N for a new one.

Controls
  W A S D / arrows   move the camera (hold Shift to move faster)
  Middle mouse drag  move the camera
  Home               back to the starting point
  Left mouse         paint selected material
  Right mouse        erase
  Mouse wheel        brush size
  1 2 3 4 5          sand / water / stone / oil / wood
  6 7 8 9 0          fire / lava / ice / steam / smoke
  Q / E              previous / next material (dirt, grass, coal, basalt...)
  T                  heat view (temperature map)
  Space              pause / resume
  .                  single step while paused
  R                  regenerate this world
  N                  new world (new seed)
  C                  clear world
  F                  show active (simulating) regions
  Esc                quit

Try: light the trees (6, fire) and watch the forest burn. Dig down (right
mouse) to find caves, pools of water and oil, and deep down, magma chambers
sealed in dark basalt - break the basalt and the lava pours out.

Command line (from a terminal in this folder):
  pixel_sandbox.exe --seed 12345     a specific world
  pixel_sandbox.exe --demo           the small hand-built demo scene
  pixel_bench.exe --scene gen --seed 12345 --steps 600    benchmark

SDL2 is used under the zlib license (see SDL2-LICENSE.txt).
