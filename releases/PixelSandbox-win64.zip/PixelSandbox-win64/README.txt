Pixel Sandbox (early build) - Windows 64-bit

Run: double-click pixel_sandbox.exe (keep SDL2.dll in the same folder).

Controls
  Left mouse      paint selected material
  Right mouse     erase
  Mouse wheel     brush size
  1 2 3 4 5       sand / water / stone / oil / wood
  6 7 8 9 0       fire / lava / ice / steam / smoke
  T               heat view (temperature map)
  Space           pause / resume
  .               single step while paused
  R               rebuild demo scene
  C               clear world
  D               show active (simulating) regions
  Esc             quit

Try: press 6 and click the dark oil pit in the middle - the fire runs along
the plank into the wooden tower. Press 2 and pour water into the lava on the
right. Press T to see the heat.

The window title shows FPS, simulation time per step and active chunks.

pixel_bench.exe is a command-line benchmark: open a terminal in this folder and run
  pixel_bench.exe --scene rain --steps 600

SDL2 is used under the zlib license (see SDL2-LICENSE.txt).
